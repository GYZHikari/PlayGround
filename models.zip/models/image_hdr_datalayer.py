import caffe
import numpy as np
import math
from PIL import Image
import scipy.io
import random
import os
import cv2

def revertHDR(hdr_log):
    hdr_ = np.exp(hdr_log) - 0.01
    hdr_[np.isinf(hdr_)] = 5000
    hdr_[np.isnan(hdr_)] = 0
    return hdr_

def ColorAugmentation(input):
    input_rc = input.transpose((2,1,0))
    input_rc = np.reshape(input.transpose((2,1,0)), (3,input.shape[0]*input.shape[1]))
    b = (np.random.rand(3,3)-0.5)*0.2
    b[0,0] = 1 - b[0,1] - b[0,2]
    b[1,1] = 1 - b[1,0] - b[1,2]
    b[2,2] = 1 - b[2,0] - b[2,1]
    output = np.matmul(input_rc, b)
    return output

def Clamp(input, min_, max_):
    output = input
    mask = np.zeros_like(input)
    output[input < min_] = min_
    output[input > max_] = max_
    mask[input < min_] = 1
    mask[input > max_] = 1
    return output, mask

def HDR2LDR(hdr_):
    # camara color correction
    if np.random.rand(1) > 0.5:
        hdr_ = ColorAugmentation(hdr_)

    # noise
    n = np.random.normal(0.9,0.1)
    sig = np.random.normal(0.6,0.1)
    hdr_flat = (1+sig)*(math.pow(hdr_.flatten(),n)/(math.pow(hdr_.flatten(),n)+sig))
    hdr_ = np.reshape(hdr_flat, hdr_.shape)

    # expo
    hdr_small = cv2.resize(hdr_, (512,512))
    v = np.random.rand(1) * (0.15-0.05) + 0.05
    a = np.sort(hdr_small.flatten())[::-1]

    # clamp and norm to ldr
    clamp_v = a[int(hdr_small.size * v)]

    ldr_, mask = Clamp(hdr_, 0, clamp_v)/clamp_v * 255
    return ldr_, mask

class ImHdrDatalayer(caffe.Layer):
    """
    Augmentation including:
    1. similarity transformation
    3. rand crop accoding to label
    4. (+ and - in tmporal
    axis) rand flip of 1st and 2nd image
    5. random 1-inter_step jump of frames

    taking 1 random image, augmente to 2 samples
    """

    def setup(self, bottom, top):
        # two parameters
        params = eval(self.param_str)
        self.root_dir = params['root']
        self.shape = np.array(params['shape'])
        self.use_mask = params.get('use_mask', False)
        self.use_mean = params.get('use_mean', True)

        # two tops: data and cbcr ground truth
        if len(top) != 2:
            raise Exception("Need to define two tops: \
        data [first ldr, second ldr, first hdr], label [second hdr]")
        # data layers have no bottoms
        if len(bottom) != 0:
            raise Exception("Do not define a bottom.")

        split_f = os.path.join(self.root_dir, 'train_all.txt')
        self.img_list = open(split_f, 'r').read().splitlines()
        self.idx = np.array(range(0, self.shape[0]))
        for id in range(self.shape[0]):
            self.idx[id] = random.randint(0, len(self.img_list)-1)


    def reshape(self, bottom, top):
        self.data = np.zeros(self.shape)
        self.label = np.zeros((self.shape[0], 3, self.shape[2], self.shape[3]))
        top[0].reshape(*self.data.shape)
        top[1].reshape(*self.label.shape)


    def forward(self, bottom, top):
        for id in range(self.shape[0]):
            image, label = self.load_imagelabel_ac(self.idx[id])
            self.data[id] = image
            self.label[id] = label
        top[0].data[...] = self.data
        top[1].data[...] = self.label
        for id in range(self.shape[0]):
            self.idx[id] = random.randint(0, len(self.img_list)-1)

    def backward(self, top, propagate_down, bottom):
        pass


    def load_imagelabel_ac(self, id):
        part = self.img_list[id].partition(' ')
        hdr_path = part[0]
        hdr_mean = np.array(part[-1],dtype=np.float32)
        hdr = scipy.io.loadmat(os.path.join(self.root_dir, hdr_path))
        hdr_log = np.array(hdr['hdr_log'],dtype = np.float32)
        # get ldr (sort in the 512*512 hdr image, maybe very slow)
        hdr = revertHDR(hdr_log)
        ldr, mask = HDR2LDR(hdr)
        # we use normed log as hdr input
        hdr = hdr_log - hdr_mean

        bd_w = self.shape[3] + 50
        bd_h = self.shape[2] + 50
        # crop according to mask
        while True:
            rw_ = int(np.random.rand(1) * (ldr.shape[1] - bd_w))
            rh_ = int(np.random.rand(1) * (ldr.shape[0] - bd_h))
            mask = mask[rh_:rh_+bd_h, rw_:rw_+bd_w]
            if len(np.unique(mask)) == 2:
                break

        hdr = hdr[rh_:rh_+bd_h, rw_:rw_+bd_w]
        ldr = ldr[rh_:rh_+bd_h, rw_:rw_+bd_w]
        y = ldr.shape[0]
        x = ldr.shape[1]

        rate = (np.random.rand(1)-0.5)/5.0
        shift_x = np.minimum(x,y) * rate
        rate = (np.random.rand(1)-0.5)/5.0
        shift_y = np.minimum(x,y) * rate
        scale = 1+(np.random.rand(1)-0.5) / 10.0
        angle = (np.random.rand(1)-0.5)*20.0

        M = np.float32([[1,0,shift_x],[0,1,shift_y]])
        hdr_p = cv2.warpAffine(hdr, M, (x,y))
        ldr_p = cv2.warpAffine(ldr, M, (x,y))
        M = cv2.getRotationMatrix2D((x/2,y/2),angle,scale)
        hdr_p = cv2.warpAffine(hdr_p, M, (x,y))
        ldr_p = cv2.warpAffine(ldr_p, M, (x,y))

        # crop the affine transformed matrics
        rw_ = int(np.random.rand(1) * (ldr_p.shape[1]-self.shape[3]))
        rh_ = int(np.random.rand(1) * (ldr_p.shape[0]-self.shape[2]))
        hdr = hdr[rh_:rh_+self.shape[2],rw_:rw_+self.shape[3]]
        ldr = ldr[rh_:rh_+self.shape[2],rw_:rw_+self.shape[3]]
        hdr_p = hdr_p[rh_:rh_+self.shape[2],rw_:rw_+self.shape[3]]
        ldr_p = ldr_p[rh_:rh_+self.shape[2],rw_:rw_+self.shape[3]]

        # flip w or h
        if np.random.rand(1) > 0.5:
            ldr = ldr[:,::-1]
            hdr = hdr[:,::-1]
            ldr_p = ldr_p[:,::-1]
            hdr_p = hdr_p[:,::-1]
        if np.random.rand(1) > 0.5:
            ldr = ldr[::-1]
            hdr = hdr[::-1]
            ldr_p = ldr_p[::-1]
            hdr_p = hdr_p[::-1]

        # LDR (common RGB) - VGG mean
        ldr = (np.array(ldr, dtype=np.float32) - np.array((123, 117, 104)))
        ldr_p = (np.array(ldr_p, dtype=np.float32) - np.array((123, 117, 104)))

        # warp to data and label
        image = np.append(ldr, ldr_p, 2)
        image = np.append(image, hdr, 2)
        label = hdr_p
        image = image.transpose((2,0,1))
        label = label.transpose((2,0,1))
        return image, label
